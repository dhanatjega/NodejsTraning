const fs = require('fs');

const destDir = 'C:/Dhanaraj/NodeJS/MyThirdDatModule/dest';
const destFile = 'C:/Dhanaraj/NodeJS/MyThirdDatModule/dest/fileexist.txt';

fs.exists(destFile, function (doesExist) {
  if (doesExist) {
    
    console.log('\nfile exists in the directory \n\n');
    getCurrentFilenames();
  } else {
   
    console.log('\nfile not found in the directory! \n\n');
    getCurrentFilenames();
  }
});

function getCurrentFilenames() {
    console.log("\nCurrent files in directory:");
    fs.readdirSync(destDir).forEach(file => {
      console.log(file);
    });
  };