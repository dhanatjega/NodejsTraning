let i;
//square function returns square of a number           
var square = function(num){  
    return num*num;
}
 //Expected output: [16 ,25, 100, 9, 64, 36]
 var modifyArray = function (arr,result, len)
{
    return function modifiedArray()
    {
            console.log("Modified array elements are ");
            for(i = 0; i < len; i++) {
                result.push(square(arr[i]));
             }
             console.log(result);
    }
}

module.exports = {modifyArray};




        