

var maskedNumber = function (arr,result, len)
{
    return function masknumbers()
    {
            console.log("Masked Numbers...");
            let text = "1234567890";
            let result = text.slice(0, 3) + "****" + text.slice(7);
             console.log(result);
    }
};

module.exports = {maskedNumber};