var objImport = require('./module1')
var objImport1 = require('./module3')
var arr = [4, 5, 10, 3, 8, 6];
var result = [];

var rest = objImport.modifyArray(arr,result,arr.length);

rest();


var results = objImport1.maskedNumber();

results();

