var objImport = require('./module')


let i=0;

var results = objImport.readAllFilesandWrite(i);

results();


