var objImport = require('./module1')

var emp = [

    {
   "Name": "Jeff",
   "Zip": "55422",
   "Age": 54,
   "Salary": 9587.23,
   "DepartmentId": 1,
   "GetTaxForm": "1099"
   },
   
   {
   "Name": "Dave",
   "Zip": "03456",
   "Age": 41,
   "Salary": 8547.55,
   "DepartmentId": 1,
   "GetTaxForm": "W2"
   },
   
   {
   "Name": "Amber",
   "Zip": "41908",
   "Age": 35,
   "Salary": 4878.1,
   "DepartmentId": 2,
   "GetTaxForm": "W2"
   },
   
   {
   "Name": "Cassie",
   "Zip": "91820",
   "Age": 28,
   "Salary": 4500,
   "DepartmentId": 1,
   "GetTaxForm": "1099"
   },
   
   {
   "Name": "Albert",
   "Zip": "54321",
   "Age": 39,
   "Salary": 5874.09,
   "DepartmentId": 2,
   "GetTaxForm": "1099"
   }
   ]

var arrPositionIndex = objImport1.findAllPosArrOfObj(emp,"Salary",4500);

arrPositionIndex();