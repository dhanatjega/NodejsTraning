var http = require("http");//core inbuilt module
var fs = require("fs");//core inbuilt module
var path = require("path");//core inbuilt module
var url=require("url");//core inbuilt module
var qs=require("querystring");//core inbuilt module

const port=3000;
var postsArr=[];

var empArr = [{ empId: 101, empName: "Asha", salary: 1001, deptId: "D1" },
            { empId: 102, empName: "Gaurav", salary: 2000, deptId: "D1" },
            { empId: 103, empName: "Karan", salary: 2000, deptId: "D2" },
            { empId: 104, empName: "Kishan", salary: 3000, deptId: "D1" },
            { empId: 105, empName: "Keshav", salary: 3500, deptId: "D2" },
            { empId: 106, empName: "Pran", salary: 4000, deptId: "D3" },
            { empId: 107, empName: "Saurav", salary: 3800, deptId: "D3" }]

var server=http.createServer((request,response)=>{
    
    console.log("Request object method", request.method);
    console.log("Request object url", request.url);
    var urlObject=url.parse(request.url);
    console.log("Url Object",urlObject);

    if (request.url == "/posts") {
        if (request.method == "DELETE") {
            removeByAttr(request.empArr, 'empId', 104);
        }
        if (request.method == "DELETE") {
            removeByAttr(request.empArr, 'empId', 104);
        }
    }
});


var removeByAttr = function(arr, attr, value){
    var i = arr.length;
    while(i--){
       if( arr[i] 
           && arr[i].hasOwnProperty(attr) 
           && (arguments.length > 2 && arr[i][attr] === value ) ){ 

           arr.splice(i,1);

       }
    }
    return arr;
}

server.listen(port, () => {
    console.log('Server is running at localhost with port number : ${port}')
})