
var maxOfArray = function (empArr,arrCount)
{
    return function maxArray()
    {
            let max = empArr[0].salary;
            for (let i = 1; i < arrCount; ++i) {
              if (arr[i] > max) {
                max = empArr[i].salary;;
              }
            }
            console.log(max);
    }
}

module.exports = {maxOfArray};