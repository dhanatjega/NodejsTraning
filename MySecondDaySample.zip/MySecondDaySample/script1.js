var objImport = require('./module2')

const empArr = [
    {
        ​​​​​​empId: 101,
        empName: "Asha",
        salary: 1001,
        deptId: "D1",
    },
    {
        ​​​​​​empId: 102,
        empName: "Gaurav",
        salary: 2000,
        deptId: "D1",
    },
    {
        ​​​​​​empId: 103,
        empName: "Mittal",
        salary: 3000,
        deptId: "D2",
    },
    {
        ​​​​​​empId: 104,
        empName: "Adithya",
        salary: 4000,
        deptId: "D3",
    },
  ];

let arrCount = empArr.length;

var maxOfArra = objImport.maxOfArray(empArr,arrCount);

maxOfArra();