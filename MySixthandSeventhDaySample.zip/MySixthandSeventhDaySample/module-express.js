const express=require("express");//module to be installed
const path=require("path");
const bodyParser=require("body-parser");//module to be installed

const morgan=require("morgan");//module to be installed
// logging of the requests -- morgan


const fs=require("fs");

const port=3000;

var productsArr = [{ productId: 101, productName: "Prod1", price: 1001, quantity: "1kg" , category: "c1"},
{ productId: 102, productName: "Prod2", price: 2000, quantity: "1kg", category: "c1" },
{ productId: 103, productName: "Prod3", price: 2000, quantity: "1kg", category: "c2" },
{ productId: 104, productName: "Prod4", price: 3000, quantity: "1kg", category: "c3" },
{ productId: 105, productName: "Prod5", price: 3500, quantity: "1kg", category: "c3" },
{ productId: 106, productName: "Prod6", price: 4000, quantity: "1kg", category: "c3" },
{ productId: 107, productName: "Prod7", price: 3800, quantity: "1kg", category: "c4" }]

var wStream=fs.createWriteStream(path.join(__dirname,"log","serverLog.txt"),{flags:"a"});


var app=express();
app.use(morgan("combined"));

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

  app.post("/products",(request,response)=>{
    productsArr.push(request.body);
    response.end("Products Details added successfully")
  })
  
  app.get("/products",(request,response)=>{
      // return an productsArr
      // implicitly set the content-type 
      // no stringify required for sending json data
      response.send(productsArr);
  })

  app.get("/products",(request,response)=>{
    var pos=productsArr.findIndex(item =>item.productName == request.productName);
    if(pos >=0)
    {
        var str1="Products Details"+ JSON.stringify(productsArr[pos]);
        response.send(str1);
    }
    else
    {
        response.sendStatus(404);
        response.send("Product not found")
    }
    response.send(productsArr);
})

  app.findIndex("/products",(request,response)=>{
    productsArr.push(request.body);
    response.end("Products Details updated successfully")
  })
