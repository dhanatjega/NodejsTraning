const fs = require('fs');
const fse = require('fs-extra');

const srcDir = 'C:/Dhanaraj/NodeJS/MyThirdDatModule/src';
const destDir = 'C:/Dhanaraj/NodeJS/MyThirdDatModule/dest';

fse.copy(srcDir, destDir, function (err) {
    if (err) {
      console.error(err);
    } else {
      console.log("success!");
      getCurrentFilenames();
    }
  }); //

  function getCurrentFilenames() {
    console.log("\nCurrent files in directory:");
    fs.readdirSync(destDir).forEach(file => {
      console.log(file);
    });
  };