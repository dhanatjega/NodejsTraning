
var findAllPosArrOfObj = function findAllPosArrOfObj(arrOfObj,fieldName,value)
{
    for(let i=0;i<arrOfObj.length;i++)
    {
        if (arrOfObj[i][fieldName] === value )
        {
            return i;
            break;
        }
    }
    return -1;
};

module.exports = {findAllPosArrOfObj};