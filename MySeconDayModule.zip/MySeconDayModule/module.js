var fs = require("fs");

var readAllFilesandWrite = function (numn)
{
    return function readAllFiles()
    {
        fs.readFile('read1.txt',function(err1, data1){
            fs.readFile('read2.txt',function(err2, data2){
                fs.readFile('read3.txt',function(err3, data3){
                     if(err1 || err2 || err3){
                           throw new Error();
                     }
                     let data = data1 + "\n" +  data2+ "\n" + data3;
                    fs.writeFile("write1.txt",data,(err)=>{
                        if(err)
                        {
                            console.log("Error writing in the file",err)
                        }
                        else
                        {
                            console.log("data written successfully");
                        }
                    });
                 });
            });
        });
    }
}

module.exports = {readAllFilesandWrite};